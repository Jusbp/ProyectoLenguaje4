<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TutoriaController;
use App\Http\Controllers\OpinionController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/tutorias', [TutoriaController::class, 'index'])->name('tutorias.index');
Route::get('/tutorias/{id}/show', [TutoriaController::class, 'show'])->where('id')->name('tutorias.show');
Route::get('/tutorias/crear', [TutoriaController::class, 'create'])->name('tutorias.create');
Route::get('/tutorias/{id}/editar', [TutoriaController::class, 'edit'])->where('id')->name('tutorias.edit');
Route::put('/tutorias/{id}/actualizar', [TutoriaController::class, 'update'])->name('tutorias.update')->middleware('auth');
Route::delete('/tutorias/{id}/eliminar', [TutoriaController::class, 'destroy']) ->where('id', '[0-9]+')->name('tutorias.destroy');

Route::get('/tutorias/crear', [TutoriaController::class, 'create'])->name('tutorias.create');
Route::post('/tutorias', [TutoriaController::class, 'store'])->name('tutorias.store');


// Opiniones
Route::get('/opiniones', [OpinionController::class, 'index'])->name('opiniones.index');
Route::get('/opiniones/crear', [OpinionController::class, 'create'])->name('opiniones.create');
Route::get('/opiniones/show/{id}', [OpinionController::class, 'show'])->where('id')->name('opiniones.show');
Route::post('/opiniones', [OpinionController::class, 'store'])->name('opiniones.store');



