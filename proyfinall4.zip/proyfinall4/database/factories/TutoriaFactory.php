<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Tutoria;
use App\Models\User;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Tutoria>
 */
class TutoriaFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
 
        return [
            'nombre' => fake()->word(),
            'tutor_id' => $this->faker->numberBetween(1, 500),
            'estudiante_id' =>$this->faker->numberBetween(1, 500),
            'materia' => fake()->word(),
            'fecha' => fake()->date(),
            'hora' => fake()->time(),
            'estado' => fake()->randomElement(['pendiente', 'completada']),
        ];
    }
}
