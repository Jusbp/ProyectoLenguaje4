<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Opinion;
use App\Models\Tutoria;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
class OpinionFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
       

        return [
            'sesion_id' => $this->faker->numberBetween(1, 500),

            'calificaion' => fake()->numberBetween(1, 5),
            'comentario' => fake()->randomElement(['excelente', 'reprobado', 'malo']),
        
        ];
    }
}
