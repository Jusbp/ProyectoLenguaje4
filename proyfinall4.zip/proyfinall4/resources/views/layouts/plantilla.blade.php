<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Tutorías</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <style>
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            font-family: 'Constantia', serif;
            font-size: 1.5rem;
            font-weight: bold;
            color: #fff;
        }
        .nav-link {
            font-family: 'Constantia', serif;
            font-size: 1.2rem;
            color: #fff;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #ccc;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="{{ url('/') }}">Tutorías</a>
            <form class="d-flex" role="search" action="{{ route('tutorias.index') }}" method="GET">
                <input class="form-control me-2" type="search" placeholder="Buscar tutoría" aria-label="Search" name="search" value="{{ request()->input('search') }}">
                <button class="btn btn-outline-light" type="submit">Buscar</button>
            </form>
        </div>
    </nav>
    <div class="container mt-4">
        @if (session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif
    </div>
    <div class="container">
        @if (request()->has('search'))
            @php
                $searchTerm = request()->input('search');
                $tutorias = \App\Models\Tutoria::where('nombre', 'like', '%' . $searchTerm . '%')->get();
            @endphp
            <h2>Resultados de la búsqueda: "{{ $searchTerm }}"</h2>
            @if ($tutorias->count() > 0)
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nombre Tutor</th>
                            <th>Tutor Id</th>
                            <th>Estudiante Id</th>
                            <th>Materia</th>
                            <th>Fecha</th>
                            <th>Hora</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($tutorias as $tutoria)
                        <tr>
                            <td>{{ $tutoria->nombre }}</td>
                            <td>{{ $tutoria->tutor_id }}</td>
                            <td>{{ $tutoria->estudiante_id }}</td>
                            <td>{{ $tutoria->materia }}</td>
                            <td>{{ $tutoria->fecha }}</td>
                            <td>{{ $tutoria->hora }}</td>
                            <td>{{ $tutoria->estado }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            @else
                <p>No se encontraron tutorías.</p>
            @endif
        @else
            @yield('contenido')
        @endif
    </div>
</body>
</html>
