@extends('layouts.plantilla')
@section('contenido')

    <h1>Lista de opiniones</h1>

<table class="table table-bordered">
    <thead class="table-dark">
        <tr>
            <th>Calificacion</th>
            <th>Comentario</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        @forelse($opiniones as $opinion)
            <tr>
                <td>{{ $opinion->calificacion }}</td>
                <td>{{ $opinion->comentario }}</td>
        
            </tr>
        @empty
            <tr>
                <td colspan="4">No hay tutorias</td>
            </tr>
        @endforelse
    </tbody>
</table>

@endsection