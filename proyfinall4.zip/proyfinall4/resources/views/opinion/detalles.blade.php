@extends('layouts.plantilla')
@section('contenido')

    <h1>Opiniones de la Tutoría {{ $idTutoria }}</h1>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Calificación</th>
                <th>Comentario</th>
            </tr>
        </thead>
        <tbody>
            @forelse($opiniones as $opinion)
                <tr>
                    <td>{{ $opinion->calificacion }}</td>
                    <td>{{ $opinion->comentario }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="2">No hay opiniones para esta tutoría.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <a href="{{ route('tutorias.index') }}" class="btn btn-primary">Volver a la lista de tutorías</a>

@endsection
