@extends('layouts.plantilla')

@section('title', 'Detalle de la Tutoría')

@section('contenido')
<h1>Detalle de la Tutoría</h1>

<table class="table table-striped">
    <tbody>
        <tr>
            <th>Nombre del tutor:</th>
            <td>{{ $tutoria->nombre_tutor }}</td>
        </tr>
        <tr>
            <th>Id del tutor:</th>
            <td>{{ $tutoria->tutor_id }}</td>
        </tr>
        <tr>
            <th>Id del estudiante:</th>
            <td>{{ $tutoria->estudiante_id }}</td>
        </tr>
        <tr>
            <th>Materia:</th>
            <td>{{ $tutoria->materia }}</td>
        </tr>
        <tr>
            <th>Fecha:</th>
            <td>{{ $tutoria->fecha }}</td>
        </tr>
        <tr>
            <th>Hora:</th>
            <td>{{ $tutoria->hora }}</td>
        </tr>
        <tr>
            <th>Estado:</th>
            <td>{{ ucfirst($tutoria->estado) }}</td>
        </tr>
    </tbody>
</table>

<h2>Opiniones</h2>
@if ($opiniones->count() > 0)
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Comentario</th>
                <th>Calificación</th>
                <th>Fecha</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($tutoria->opiniones as $opinion)
            <tr>
                <td>{{ $opinion->comentario }}</td>
                <td>{{ $opinion->calificacion }}</td>
                <td>{{ $opinion->created_at }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
@else
    <p>No hay opiniones disponibles para esta tutoría.</p>
@endif

<a href="{{ route('tutorias.index') }}" class="btn btn-secondary">Volver</a>
@endsection
