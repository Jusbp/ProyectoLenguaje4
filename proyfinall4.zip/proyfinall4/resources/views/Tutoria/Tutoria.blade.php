@extends('layouts.plantilla')

@section('contenido')

<h1>Lista de tutorias
    <a class="btn btn-success" href="{{ route('tutorias.create') }}">Crear tutoria</a>
</h1>

@if (session('exito'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('exito') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
@endif

<table class="table table-bordered">
    <thead class="table-dark">
        <tr>
            <th>Nombre Tutor</th>
            <th>Tutor Id</th>
            <th>Estudiante Id</th>
            <th>Materia</th>
            <th>Fecha</th>            
            <th>Hora</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        @forelse($tutorias as $tutoria)
            <tr>
                <td>{{ $tutoria->nombre }}</td>
               <td>{{ $tutoria->tutor_id }}</td>
               <td>{{ $tutoria->estudiante_id }}</td>
                <td>{{ $tutoria->materia }}</td>
                <td>{{ $tutoria->fecha }}</td>
                <td>{{ $tutoria->hora }}</td>
                <td>{{ $tutoria->estado }}</td>
                
                <td>
                    <a href="{{ route('tutorias.edit', $tutoria->id) }}" class="btn btn-primary btn-sm">Editar</a>

                    <form action="{{ route('tutorias.destroy', $tutoria->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('delete')
                        <button type="submit" class="btn btn-danger btn-sm" 
                                onclick="return confirm('¿Estás seguro de que deseas eliminar la tutoria: {{ $tutoria->nombre }}?');">
                            Eliminar
                        </button>
                    </form>

                    <a href="{{ route('tutorias.show', $tutoria->id) }}" class="btn btn-info btn-sm">Detalles</a>

                    

                </td>
            </tr>
        @empty
            <tr>
                <td colspan="4">No hay tutorias</td>
            </tr>
        @endforelse
    </tbody>
</table>

{{ $tutorias->links('pagination::bootstrap-5') }}

@endsection
