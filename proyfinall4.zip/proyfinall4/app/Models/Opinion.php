<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Tutoria;

class Opinion extends Model
{
    use HasFactory;

    protected $fillable = [
        'sesion_id',
        'calificacion',
        'comentario',
    ];

    public function tutoria()
    {
        return $this->belongsTo(Tutoria::class, 'sesion_id');
    }
}
