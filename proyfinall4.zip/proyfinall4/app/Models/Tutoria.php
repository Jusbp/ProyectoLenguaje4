<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Opinion;

class Tutoria extends Model
{
    use HasFactory;

    protected $fillable = [
        'nombre',
        'tutor_id',
        'estudiante_id',
        'materia',
        'fecha',
        'hora',
        'estado',
    ];

    public function opiniones()
    {
        return $this->hasMany(Opinion::class, 'sesion_id');
    }
}
