<?php

namespace App\Http\Controllers;

use App\Models\Opinion;
use App\Models\Tutoria;
use Illuminate\Http\Request;

class OpinionController extends Controller
{
    public function index()
    {
        //$opiniones = Opinion::paginate(10);
        //return view('opinion.index', compact('opiniones'));
        $opiniones = Opinion::with('tutoria')->get();
        return view('opinione.index', compact('opiniones'));
    }

    public function create($tutoriaId)
    {
        $tutoria = Tutoria::findOrFail($tutoriaId);
        return view('opinion.create', compact('tutoria'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'sesion_id' => 'required|exists:tutorias,id',
            'calificacion' => 'required|integer|min:1|max:5',
            'comentario' => 'required|string|max:500',
        ]);

        $opinion = Opinion::create($request->all());
        return redirect()->route('opiniones.index')->with('success', 'Opinión registrada correctamente.');
    }

    public function destroy(Opinion $opinion)
    {
        $opinion->delete();
        return redirect()->route('opiniones.index')->with('success', 'Opinión eliminada correctamente.');
    }
}
