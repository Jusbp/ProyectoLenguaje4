<?php

namespace App\Http\Controllers;

use App\Models\Tutoria;
use Illuminate\Http\Request;

class TutoriaController extends Controller
{
    public function index()
    {
        $tutorias = Tutoria::paginate(10);
        return view('Tutoria.tutoria', compact('tutorias'));
    }

    public function show($id)
    {
        $tutoria = Tutoria::findOrFail($id);
        $opiniones = $tutoria->opiniones;
        return view('Tutoria.show', compact('tutoria', 'opiniones'));
    }

    public function create()
    {
        return view('Tutoria.formulario');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:80|min:3',
            'tutor_id' => 'required|numeric|min:1',
            'estudiante_id' => 'required|numeric|min:1',
            'materia' => 'required|string|max:50',
            'fecha' => 'required|date',
            'hora' => 'required|date_format:H:i',
            'estado' => 'required|string|in:pendiente,completada,cancelada',
        ]);

        $tutoria = Tutoria::create($request->all());
        return redirect()->route('tutorias.index')->with('success', 'Tutoría creada exitosamente.');
    }

    public function edit(Tutoria $tutoria)
    {
        return view('Tutoria.formulario', compact('tutoria'));
    }

    public function update(Request $request, Tutoria $tutoria)
    {
        $request->validate([
            'nombre' => 'required|string|max:80|min:3',
            'tutor_id' => 'required|numeric|min:1',
            'estudiante_id' => 'required|numeric|min:1',
            'materia' => 'required|string|max:50',
            'fecha' => 'required|date',
            'hora' => 'required|date_format:H:i',
            'estado' => 'required|string|in:pendiente,completada,cancelada',
        ]);

        $tutoria->update($request->all());
        return redirect()->route('tutorias.index')->with('success', 'Tutoría actualizada exitosamente.');
    }

    public function destroy($id)
    {
        $tutoria = Tutoria::findOrFail($id);
        $tutoria->delete();
        return redirect()->back()->with('success', 'Tutoría eliminada exitosamente.');
    }
}
