

<?php $__env->startSection('title', 'Detalle de la Tutoría'); ?>

<?php $__env->startSection('contenido'); ?>
<h1>Detalle de la Tutoría</h1>

<table class="table table-striped">
    <tbody>
        <tr>
            <th>Nombre del tutor:</th>
            <td><?php echo e($tutoria->nombre_tutor); ?></td>
        </tr>
        <tr>
            <th>Id del tutor:</th>
            <td><?php echo e($tutoria->tutor_id); ?></td>
        </tr>
        <tr>
            <th>Id del estudiante:</th>
            <td><?php echo e($tutoria->estudiante_id); ?></td>
        </tr>
        <tr>
            <th>Materia:</th>
            <td><?php echo e($tutoria->materia); ?></td>
        </tr>
        <tr>
            <th>Fecha:</th>
            <td><?php echo e($tutoria->fecha); ?></td>
        </tr>
        <tr>
            <th>Hora:</th>
            <td><?php echo e($tutoria->hora); ?></td>
        </tr>
        <tr>
            <th>Estado:</th>
            <td><?php echo e(ucfirst($tutoria->estado)); ?></td>
        </tr>
    </tbody>
</table>

<h2>Opiniones</h2>
<?php if($opiniones->count() > 0): ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Comentario</th>
                <th>Calificación</th>
                <th>Fecha</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tutoria->opiniones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opinion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($opinion->comentario); ?></td>
                <td><?php echo e($opinion->calificacion); ?></td>
                <td><?php echo e($opinion->created_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No hay opiniones disponibles para esta tutoría.</p>
<?php endif; ?>

<a href="<?php echo e(route('tutorias.index')); ?>" class="btn btn-secondary">Volver</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyfinall4\resources\views/Tutoria/show.blade.php ENDPATH**/ ?>