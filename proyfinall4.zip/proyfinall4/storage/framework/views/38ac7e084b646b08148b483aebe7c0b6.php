
<?php $__env->startSection('contenido'); ?>
    <?php if(isset($tutoria)): ?>
        <h1>Editar producto</h1>
    <?php else: ?>
        <h1>Crear nueva tutoria</h1>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form class="form-floating" method="post" >
        <?php if(isset($tutoria)): ?>
            <?php echo method_field('put'); ?>
        <?php endif; ?>

        <?php echo csrf_field(); ?>
           <div class="row">
                <div class="col-md-6">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre del tutor" value="<?php echo e(isset($tutoria)? $tutoria->nombre: old('nombre')); ?>">
                      <label for="nombre">Nombre del tutor</label>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" id="materia" name="materia" placeholder="Materia" value="<?php echo e(isset($tutoria) ? $tutoria->materia : old('materia')); ?>">
                        <label for="materia">Materia</label>
                    </div>
                </div>
                <div class="row">
                <div class="col-md-4">
                    <div class="form-floating mb-3">
                        <input type="number" class="form-control" id="tutor_id" name="tutor_id" placeholder="Id Tutor" value="<?php echo e(isset($tutoria) ? $tutoria->tutor_id : old('tutor_id')); ?>">
                        <label for="tutor_id">Tutor Id</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-floating mb-3">
                        <input type="number" class="form-control" id="estudiante_id" name="estudiante_id" placeholder="Id Estudiante" value="<?php echo e(isset($tutoria) ? $tutoria->estudiante_id : old('estudiante_id')); ?>">
                        <label for="estudiante_id">Estudiante Id</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-floating mb-3">
                        <input type="date" class="form-control" id="fecha" name="fecha" placeholder="Fecha" value="<?php echo e(isset($tutoria) ? $tutoria->fecha : old('fecha')); ?>">
                        <label for="fecha">Fecha</label>
                    </div>
                </div>
                <div class="row">
                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <input type="time" class="form-control" id="hora" name="hora" placeholder="Hora" value="<?php echo e(isset($tutoria) ? $tutoria->hora : old('hora')); ?>">
                        <label for="hora">Hora</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" id="estado" name="estado" placeholder="Estado" value="<?php echo e(isset($tutoria) ? $tutoria->estado : old('estado')); ?>">
                        <label for="estado">Estado</label>
                    </div>
                </div>
            </div>
            </div>
           

            <div class="row">
                <div class="col">
                  <input type="submit" value="Guardar" class="btn btn-primary">
                 <input type="reset" value="Limpiar" class="btn btn-danger">
               </div>
            </div>
        </div>


    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyfinall4\resources\views/Tutoria/formulario.blade.php ENDPATH**/ ?>