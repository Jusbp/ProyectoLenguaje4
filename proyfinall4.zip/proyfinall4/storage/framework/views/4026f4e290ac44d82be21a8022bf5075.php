
<?php $__env->startSection('title', 'Opiniones'); ?>
<?php $__env->startSection('contenido'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Lista de opiniones</h1>

<table class="table table-bordered">
    <thead class="table-dark">
        <tr>
            <th>Calificacion</th>
            <th>Comentario</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $opiniones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opinion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($opinion->calificacion); ?></td>
                <td><?php echo e($opinion->comentario); ?></td>
        
                
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4">No hay tutorias</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<div class="container">
    <?php echo $__env->yieldContent(content); ?>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyfinall4\resources\views/opinion/opinion.blade.php ENDPATH**/ ?>