

<?php $__env->startSection('contenido'); ?>

<h1>Lista de tutorias
    <a class="btn btn-success" href="<?php echo e(route('tutorias.create')); ?>">Crear tutoria</a>
</h1>

<?php if(session('exito')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('exito')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<table class="table table-bordered">
    <thead class="table-dark">
        <tr>
            <th>Nombre Tutor</th>
            <th>Tutor Id</th>
            <th>Estudiante Id</th>
            <th>Materia</th>
            <th>Fecha</th>            
            <th>Hora</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $tutorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($tutoria->nombre); ?></td>
               <td><?php echo e($tutoria->tutor_id); ?></td>
               <td><?php echo e($tutoria->estudiante_id); ?></td>
                <td><?php echo e($tutoria->materia); ?></td>
                <td><?php echo e($tutoria->fecha); ?></td>
                <td><?php echo e($tutoria->hora); ?></td>
                <td><?php echo e($tutoria->estado); ?></td>
                
                <td>
                    <a href="<?php echo e(route('tutorias.edit', $tutoria->id)); ?>" class="btn btn-primary btn-sm">Editar</a>

                    <form action="<?php echo e(route('tutorias.destroy', $tutoria->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" 
                                onclick="return confirm('¿Estás seguro de que deseas eliminar la tutoria: <?php echo e($tutoria->nombre); ?>?');">
                            Eliminar
                        </button>
                    </form>

                    <a href="<?php echo e(route('tutorias.show', $tutoria->id)); ?>" class="btn btn-info btn-sm">Detalles</a>

                    

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4">No hay tutorias</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php echo e($tutorias->links('pagination::bootstrap-5')); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyfinall4\resources\views/Tutoria/tutoria.blade.php ENDPATH**/ ?>