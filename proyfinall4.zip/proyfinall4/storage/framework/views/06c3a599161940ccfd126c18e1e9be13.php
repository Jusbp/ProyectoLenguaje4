<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Tutorías</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <style>
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            font-family: 'Constantia', serif;
            font-size: 1.5rem;
            font-weight: bold;
            color: #fff;
        }
        .nav-link {
            font-family: 'Constantia', serif;
            font-size: 1.2rem;
            color: #fff;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #ccc;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Tutorías</a>
            <form class="d-flex" role="search" action="<?php echo e(route('tutorias.index')); ?>" method="GET">
                <input class="form-control me-2" type="search" placeholder="Buscar tutoría" aria-label="Search" name="search" value="<?php echo e(request()->input('search')); ?>">
                <button class="btn btn-outline-light" type="submit">Buscar</button>
            </form>
        </div>
    </nav>
    <div class="container mt-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
    </div>
    <div class="container">
        <?php if(request()->has('search')): ?>
            <?php
                $searchTerm = request()->input('search');
                $tutorias = \App\Models\Tutoria::where('nombre', 'like', '%' . $searchTerm . '%')->get();
            ?>
            <h2>Resultados de la búsqueda: "<?php echo e($searchTerm); ?>"</h2>
            <?php if($tutorias->count() > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nombre Tutor</th>
                            <th>Tutor Id</th>
                            <th>Estudiante Id</th>
                            <th>Materia</th>
                            <th>Fecha</th>
                            <th>Hora</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tutorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($tutoria->nombre); ?></td>
                            <td><?php echo e($tutoria->tutor_id); ?></td>
                            <td><?php echo e($tutoria->estudiante_id); ?></td>
                            <td><?php echo e($tutoria->materia); ?></td>
                            <td><?php echo e($tutoria->fecha); ?></td>
                            <td><?php echo e($tutoria->hora); ?></td>
                            <td><?php echo e($tutoria->estado); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No se encontraron tutorías.</p>
            <?php endif; ?>
        <?php else: ?>
            <?php echo $__env->yieldContent('contenido'); ?>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\proyfinall4\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>